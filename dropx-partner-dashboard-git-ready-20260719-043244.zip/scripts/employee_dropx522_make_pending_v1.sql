update public.employees
set profile_completion_status = 'pending',
    profile_completed_at = null,
    updated_at = now()
where employee_code = 'DROPX522';
