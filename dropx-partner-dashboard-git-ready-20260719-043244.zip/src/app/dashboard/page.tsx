export { default } from "../page";
